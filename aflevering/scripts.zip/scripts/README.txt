The forecast data from the project has been omitted in the hand-in version of the scrips.
This is because this is the property of Energinet and not publically available.

Please also note that in order to run the scripts, there are two lines in each scripts where the path
needs to be copied in, in order for the scripts to succesfully run. 